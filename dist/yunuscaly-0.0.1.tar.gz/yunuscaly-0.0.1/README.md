

# Yunuscaly

This package will help you to do  calculations quickly.

## How to Install it?

## On Windows

```
pip install  yunuscaly
```

## On Linux:

```
sudo pip3 install yunuscaly
```

## How to use it?

### Initializing Package
```
from  yunuscaly import Yunuscaly

num_1 = 4
num_2 = 5

calc = Yunuscaly(num_1, num_2)
```

### Adding Numbers
```
calc.addition()
```

### Substracting Numbers
```
calc.substraction()
```

### Multiplying Numbers
```
calc.multiplication()
```

### Dividing Numbers
```
calc.division()
```

### Squreroot Numbers
```
calc.squreroot()
```

### Squre Numbers
```
calc.squre()
```

### Cuberoot Numbers
```
calc.cuberoot()
```
### Cube Numbers
```
calc.cube()
```
### Power  Numbers
```
calc.power()
```
### Percentage Numbers
```
calc.percentage()
```
